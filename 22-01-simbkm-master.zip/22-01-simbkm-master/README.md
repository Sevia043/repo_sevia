# Sistem Informasi MBKM

General project description.

Read the [detailed documentation](/docs/README.md) for futher information.

Find the [codebase here](/webapp).

## Contributors

12S20017	Lile Asima Manalu	@Lilemanalu

12S20022	Agnes Veronika Sihombing	@agnesveronika22

12S20026	Mastuari Octafina Sirumapea	@Mastuariotf26

12S20034	Daniel Paskah Totti Limbong	@DanielLimbong

12S20038	Arni Febryarti Sitorus	@arniisitorus

12S20043	Sevia Rajagukguk	@Sevia043

12S20048	Jevania	@Jevania

12S20049	Meida Enggelica Butarbutar	@meidabutarbutar

12S20051	Rony Samuel Sinaga @ronysinaga29

12S20054	Rossianna Dewi Sri Hutabarat	@rossiannahutabarat
