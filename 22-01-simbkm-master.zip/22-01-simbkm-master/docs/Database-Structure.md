# Database Structure
![Database](https://user-images.githubusercontent.com/70987779/196147228-d09b966b-f55d-4ee3-90b8-d038e031cd80.jpg)

## Physical Data Model


## Data Description
the tables contained in the SIMBKM database are:
- PIC
The pic table contains the ID of the PIC and the name of the PIC. The PIC is in charge of seeing proposals and determining Supervisors for students.

- SUPERVISOR
The supervisor table contains the ID of the supervisor, the name of the supervisor and the ID of the PIC (PIC ID is taken from the PIC table). Supervisors are tasked with examining proposals, assessing proposals and viewing activities.

- Student
The student table contains student ID information, name, faculty, email, semester, phone number, study program, and gpa. Student is the main character in SIMBKM whose job is to view information, make proposals and report activities every week.

- Proposal
The proposal table contains information on the ID of the proposal, Address, ID of the PIC, ID of the Supervisor, ID of the student. Proposals are a requirement for students to participate in MBKM. So, information from the proposal is an important thing in this SIMBKM.

- Proposal Rubric
The Proposal Rubric contains the ID of the Proposal and the assessment component. The Rubric proposal becomes the benchmark for the Supervisor to provide an assessment of the proposal so that it can later be approved.

- Activity
The Activity table contains the ID of the activity, the status, the period of the activity, and the ID of the Student. The Activity table contains information on the activities carried out by students each week.

- Weekly Report
The Weekly Report table contains information from the ID of the activity, the Report Description, and the Date Description. In the Weekly Report Table is additional information that will be filled in by students in making their activities.

- Assessment Rubric
The Assessment Rubric table contains the ID of the activity and the Assessment Rubric. This table will include an activity assessment so that supervisors can assess the activities that have been carried out by students.

## Related

+ [Table of Content](README.md).
+ [Software Requirements](Software-Requirements.md).
+ [Installation](Installation.md).
+ [Features](Features.md)
+ [Database Structure](Database-Structure.md)
