# Installation

On this page we describe the detail steps to install the system for both in the production and development environments. Before intalling the system, make sure to comply with the required software mentioned in the [Software Requirements](Software-Requirements.md).

## Production Environment

## Development Environment

## Related

+ [Table of Content](README.md).
+ [Software Requirements](Software-Requirements.md).
+ [Installation](Installation.md).