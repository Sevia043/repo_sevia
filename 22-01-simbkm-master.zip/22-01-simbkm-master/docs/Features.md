# Database Structure

On this page we provide the lists of both functional and non functional requirements.

## Functional Requirements

### FR01 (Dynamic proposal generation)
Dynamic proposal generation BPMN
![New Model](https://user-images.githubusercontent.com/71372262/197320805-08171273-a434-43e9-aab2-b7d4609aa5a4.png)


In this feature, when students want to make a proposal to take part in an activity, students will be directed to fill out a form. The form contains program data that students want to participate in. The fields that will be entered by students are divided into 2 parts:
1. Proposed activities
The proposed activity contains: Name of activity; Forms of activity; Operator; Credit; the position of the organizer; Recognition; Implementation Period; Implementation method; general description; requirements; and activity URL.
2. Profile and Learning Outcomes of Graduates
This section contains: Profile of Intended Graduates; Competencies Formed Through Activities; Supporting Courses; Supporting Experience; Conformity Rationalization; Motivation Videos; and the Advisor's Proposal.

After filling out the proposal form, the system generates the proposal into a document that can be downloaded later. Then Lecturers can view student proposals in the form of documents that can be downloaded in pdf form.

note: in the section "Competencies Formed Through Activities" students choose the CPMK that is relevant to the activity they choose.
## Non Functional Requirements

### NFR01 Maintainability


## Mockup

Put and describe your mockup. Pin point into which FR or NFR it your mockup adheres.
Deskripsi mock up : 

<Mahasiswa>
Pada sistem informasi MBKM, user dapat melakukan login tanpa harus melakukan registrasi terlebih dahulu karena sudah terdaftar dan terhubung dengan data di CIS. 
Setelah melakukan login, user dapat mengisi dan melengkapi data diri pada menu my account, user tidak akan dapat melanjutkan pengajuan program jika data diri belum lengkap.
Saat user sudah melengkapi data diri, maka user dapat melihat tampilan dashboard. Pada tampilan dashboard, user dapat mendownload template proposal yang nantinya dapat digunakan untuk pengajuan proposal. Selain menu download template proposal, pada dashboard juga terdapat button yang jika di klik akan diarahkan ke halaman baru, dimana pada halaman ini user dapat mengajukan program yang diminati dengan mensubmit link kegiatan. Tujuannya adalah agar PIC MBKM dapat melakukan seleksi pertama terhadap program yang diajukan oleh mahasiswa. Setelah PIC MBKM melakukan seleksi, program yang direkomendasikan akan ditampilkan di halaman program. Pada halaman ini mahasiswa dapat melihat dan memilih program yang direkomendasikan agar selanjutnya mahasiswa dapat mengajukan proposal sesuai dengan program yang diminati. 
Kemudian, setelah proposal yang telah di submit mahasiswa di review oleh PIC MBKM dan dosen pembimbing, maka selanjutnya mahasiswa akan mendapat notifikasi apakah proposal disetujui atau tidak disetujui.Apabila proposal mahasiswa disetujui, maka mahasiswa dapat mendownload Surat Rekomendasi dan beberapa file lainnya yang diperlukan untuk mendaftar seperti SPTJM, Transkip nilai dan lain-lain. Setelah mendapat semua file-file yang diperlukan untuk mendaftar, mahasiswa dapat melanjutkan seleksi dari pihak penyelenggaranya. Jika lolos, maka mahasiswa akan dapat mengisi weekly report dan final report pada menu kegiatan aktif.
 

  

<PIC MBKM>
Pada sistem informasi MBKM, user dapat melakukan login tanpa harus melakukan registrasi terlebih dahulu karena sudah terdaftar dan terhubung dengan data di CIS. 
Setelah melakukan login, user dapat mengisi dan melengkapi data diri pada menu my account, user tidak akan dapat melanjutkan pengajuan program jika data diri belum lengkap.
Saat user sudah melengkapi data diri, maka user dapat melihat tampilan dashboard. 
Pada dashboard, PIC dapat melakukan seleksi tahap pertama (mereview proposal).
Setelah selesai diseleksi, PIC menyetujui proposal dan merekomendasikan program yang akan diikuti mahasiswa.
PIC kemudian mengupload Surat Rekomendasi, SPTJM, Transkip Nilai, dan file-file lain yang dibutuhkan mahasiswa.
Setelah itu PIC mengisikan dosen pembimbing untuk mahasiswa yang lolos program MBKM
PIC juga dapat melihat dan mengomentari weekly report dan final report yang dilakukan mahasiswa.


Link gambar untuk PIC MBKM dapat dilihat dibawah ini: 
  ![Review Proposal ](https://user-images.githubusercontent.com/70991904/196144375-00aec890-185b-4619-be44-1b17c1ac0e20.png)
  
<Dosen Pembimbing>
Pada sistem informasi MBKM, user dapat melakukan login tanpa harus melakukan registrasi terlebih dahulu karena sudah terdaftar dan terhubung dengan data di CIS. 
Setelah melakukan login, user dapat mengisi dan melengkapi data diri pada menu my account, user tidak akan dapat melanjutkan pengajuan program jika data diri belum lengkap.
Saat user sudah melengkapi data diri, maka user dapat melihat tampilan dashboard. 
Pada tampilan dashboard, Dosen Pembimbing dapat melakukan seleksi tahap pertama (meriview proposal).
Dosen Pembimbing juga dapat melihat, mengomentari, dan menilai weekly report dan final report yang dilakukan mahasiswa.

Link mockup : ![review Proposal](https://user-images.githubusercontent.com/70991088/196143306-de92054f-6774-4a1f-9afc-11d75191a692.png)

## Related

+ [Table of Content](README.md).
+ [Software Requirements](Software-Requirements.md).
+ [Installation](Installation.md).
+ [Features](Features.md)
+ [Database Structure](Database-Structure.md)
