<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WeeklyReport;

class EditLaporanController extends Controller
{
    //
    // public function getlaporan(Request $request, $id){
    //     $data = WeeklyReport::where('waktu_pelaporan', $id)->first();
    //     return view("fitur.editlaporan", compact('data'));
    // }
}
