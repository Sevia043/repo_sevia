@extends("layouts.fitur")

@section('content')

<div class="row">
  <!-- Snow Theme -->
  <div class="col-12">
    <div class="card mb-4">
      <h5 class="card-header">Studi Independent</h5>
    
        <div id="snow-toolbar">
        
        </div>
        <div id="snow-editor">
          <h6>Artificial Intelligence Technology (AI-HACKER)</h6>
          <p> Artificial Intelligence Technology (AI-HACKER)
BISA AI ACADEMY
        <p>South Jakarta City<p>
</p>
        </div>
      </div>
    </div>
  </div>

  <!-- /Snow Theme -->
  <!-- Bubble Theme -->
  <div class="col-12">
    <div class="card mb-4">
      <h5 class="card-header">Studi Independent</h5>
      <div class="card-body">
        <div id="bubble-toolbar">
          <span class="ql-formats">
            <select class="ql-font"></select>
            <select class="ql-size"></select>
          </span>
          <span class="ql-formats">
            <button class="ql-bold"></button>
            <button class="ql-italic"></button>
            <button class="ql-underline"></button>
            <button class="ql-strike"></button>
          </span>
          <span class="ql-formats">
            <select class="ql-color"></select>
            <select class="ql-background"></select>
          </span>
          <span class="ql-formats">
            <button class="ql-script" value="sub"></button>
            <button class="ql-script" value="super"></button>
          </span>
          <span class="ql-formats">
            <button class="ql-header" value="1"></button>
            <button class="ql-header" value="2"></button>
            <button class="ql-blockquote"></button>
            <button class="ql-code-block"></button>
          </span>
        </div>
        <div id="bubble-editor">
          <h6>Backend Engineering
Ruangguru</h6>
          <p> </p>
        </div>
      </div>
    </div>
  </div>

</div>

            
          </div>

@endsection